package org.iiht.controller;

import java.util.HashMap;

import org.iiht.entities.LoginDetails;
import org.iiht.service.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;



@Controller
public class HelloController {
	@Autowired
	private LoginService service;
	@RequestMapping("/")
	public ModelAndView index() {
		return new ModelAndView("index", new HashMap<>());
	}
	@RequestMapping("/loginForRegistered")
	public ModelAndView loginForRegistered() {
		return new ModelAndView("loginForRegistered", new HashMap<>());
	}
	@RequestMapping("/visitors")
	public ModelAndView visitorsPage() {
		return new ModelAndView("visitors", new HashMap<>());
	}
	@RequestMapping("/registered")
	public ModelAndView registeredPage() {
		return new ModelAndView("registered", new HashMap<>());
	}
	@RequestMapping("/admin")
	public ModelAndView adminPage() {
		return new ModelAndView("admin", new HashMap<>());
	}
	@RequestMapping("/login")
	public ModelAndView loginPage() {
		return new ModelAndView("login", new HashMap<>());
	}
	@RequestMapping("/forgot")
	public ModelAndView forgotPage() {
		return new ModelAndView("forgot", new HashMap<>());
	}
	@RequestMapping("/register")
	public ModelAndView registerPage() {
		return new ModelAndView("register", new HashMap<>());
	}
	@RequestMapping("/placeOrder")
	public ModelAndView placeOrder() {
		return new ModelAndView("placeOrder", new HashMap<>());
	}
	@RequestMapping("/contactPage")
	public ModelAndView contactPage() {
		return new ModelAndView("contactUs", new HashMap<>());
	}
	@RequestMapping("/viewOrder")
	public ModelAndView viewOrderByUser() {
		return new ModelAndView("viewOrder", new HashMap<>());
	}
	
	@RequestMapping("/validate")
	public ModelAndView validateEmail(@RequestParam String username,@RequestParam String password )
	{
		LoginDetails details=service.validateEmail(username,password);
		if(details==null) {
			return new ModelAndView("login", new HashMap<>());
		}
		else {
			return new ModelAndView("registered", new HashMap<>());		
		}
	}
}
