package org.iiht.dao;

public interface GiftCardDao {

}
