package org.iiht.dao;

import org.iiht.entities.LoginDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;


@Repository
public interface LoginDAO extends JpaRepository<LoginDetails, Integer> {
	@Query("select d from LoginDetails d  where username =?1 and password=?2")
	LoginDetails validateEmail(String username, String password);	
}
