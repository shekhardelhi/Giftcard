package org.iiht.entities;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
@Entity
public class GiftCard {
@Id
@GeneratedValue
private int orderNum;
private int giftCardAmount;
private String recipientFName;
private String recipientLName;
private String street;
private String city;
private String state;
private String country;
private int pincode;
private String buyersFName;
private String buyersLName;
private Long phoneNo ;
private String eMail;
public int getOrderNum() {
	return orderNum;
}
public void setOrderNum(int orderNum) {
	this.orderNum = orderNum;
}
public int getGiftCardAmount() {
	return giftCardAmount;
}
public void setGiftCardAmount(int giftCardAmount) {
	this.giftCardAmount = giftCardAmount;
}
public String getRecipientFName() {
	return recipientFName;
}
public void setRecipientFName(String recipientFName) {
	this.recipientFName = recipientFName;
}
public String getRecipientLName() {
	return recipientLName;
}
public void setRecipientLName(String recipientLName) {
	this.recipientLName = recipientLName;
}
public String getStreet() {
	return street;
}
public void setStreet(String street) {
	this.street = street;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}
public String getCountry() {
	return country;
}
public void setCountry(String country) {
	this.country = country;
}
public int getPincode() {
	return pincode;
}
public void setPincode(int pincode) {
	this.pincode = pincode;
}
public String getBuyersFName() {
	return buyersFName;
}
public void setBuyersFName(String buyersFName) {
	this.buyersFName = buyersFName;
}
public String getBuyersLName() {
	return buyersLName;
}
public void setBuyersLName(String buyersLName) {
	this.buyersLName = buyersLName;
}
public Long getPhoneNo() {
	return phoneNo;
}
public void setPhoneNo(Long phoneNo) {
	this.phoneNo = phoneNo;
}
public String geteMail() {
	return eMail;
}
public void seteMail(String eMail) {
	this.eMail = eMail;
}
}
