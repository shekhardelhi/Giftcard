package org.iiht.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="LoginInfo")	
public class LoginDetails {
	@Id
	@Column(length=8)
	private String loginID;
	@Column(length=25)
	private String username;
	@Column(length=10)
	private String password;
	public String getLoginID() {
		return loginID;
	}
	public void setLoginID(String loginID) {
		this.loginID = loginID;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "LoginDetails [employeeID=" + loginID + ", username=" + username + ", password=" + password + "]";
	}
	
	
}
