package org.iiht.service;

public interface GiftCardService {

}
