package org.iiht.service;

import org.iiht.entities.LoginDetails;

public interface LoginService {

	LoginDetails validateEmail(String username, String password);

	
}
