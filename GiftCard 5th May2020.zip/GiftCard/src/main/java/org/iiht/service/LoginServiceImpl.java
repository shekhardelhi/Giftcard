package org.iiht.service;

import javax.transaction.Transactional;

import org.iiht.dao.LoginDAO;
import org.iiht.entities.LoginDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
@Transactional
public class LoginServiceImpl implements LoginService {

	@Autowired
	private LoginDAO dao;
	
	@Override
	public LoginDetails validateEmail(String username, String password)  {
		return dao.validateEmail(username,password);
	}

}
