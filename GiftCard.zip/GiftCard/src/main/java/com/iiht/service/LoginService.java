package com.iiht.service;

import com.iiht.entity.LoginDetails;

public interface LoginService {

	LoginDetails validateEmail(String username, String password);

	
}
