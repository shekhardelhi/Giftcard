package com.iiht.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iiht.dao.LoginDAO;
import com.iiht.entity.LoginDetails;
@Service
@Transactional
public class LoginServiceImpl implements LoginService {

	@Autowired
	private LoginDAO dao;
	
	@Override
	public LoginDetails validateEmail(String username, String password)  {
		return dao.validateEmail(username,password);
	}

}
