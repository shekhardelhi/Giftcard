package com.iiht;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCruDwithDatajpa1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringCruDwithDatajpa1Application.class, args);
	}

}
