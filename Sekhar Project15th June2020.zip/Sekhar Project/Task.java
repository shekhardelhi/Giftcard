package com.iiht;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Task {
	private String taskName;
	private int taskPriority;
	private String taskStatus;
	private String taskStartDate;
	private String taskEndDate;
	private String taskColorCode;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public String getTaskName() {
		return taskName;
	}
	
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	public int getTaskPriority() {
		return taskPriority;
	}
	public void setTaskPriority(int taskPriority) {
		this.taskPriority = taskPriority;
	}
	public String getTaskStatus() {
		return taskStatus;
	}
	public void setTaskStatus(String taskStatus) {
		this.taskStatus = taskStatus;
	}
	public String getTaskStartDate() {
		return taskStartDate;
	}
	public void setTaskStartDate(String taskStartDate) {
		this.taskStartDate = taskStartDate;
	}
	public String getTaskEndDate() {
		return taskEndDate;
	}
	public void setTaskEndDate(String taskEndDate) {
		this.taskEndDate = taskEndDate;
	}
	public String getTaskColorCode() {
		return taskColorCode;
	}
	public void setTaskColorCode(String taskColorCode) {
		this.taskColorCode = taskColorCode;
	}
	
	
	
	
	
	
	
	
	
	

}
