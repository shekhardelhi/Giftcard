package com.iiht;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller

public class TaskController {
	@RequestMapping("/new")
	public String showNewProductForm(Model model)
	{
		Task task=new Task();
		model.addAttribute("task",task);
		return "Newtask";
	}

}
